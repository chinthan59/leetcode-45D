def pal(s):
    if s==s[::-1]:
        print("Yes")
    else:
        print("No")
s="madam"
pal(s[1:4])