con=[chr(i) for i in range(65,91) if chr(i) not in 'aeiouAEIOU'] + [chr(i) for i in range(97,123) if chr(i) not in 'aeiouAEIOU']
print(con)